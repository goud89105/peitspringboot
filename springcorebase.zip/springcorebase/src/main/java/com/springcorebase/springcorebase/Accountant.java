package com.springcorebase.springcorebase;

import org.springframework.stereotype.Component;

@Component
public class Accountant implements Employee {

	@Override
	public void doWork() {
		System.out.println("acountent");
		
	}

}
