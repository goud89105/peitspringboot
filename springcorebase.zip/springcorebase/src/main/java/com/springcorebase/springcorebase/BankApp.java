package com.springcorebase.springcorebase;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class BankApp {

	public static void main(String[] args) {

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		Accountant mang = context.getBean(Accountant.class);
		mang.doWork();
		context.close();
	}
}
