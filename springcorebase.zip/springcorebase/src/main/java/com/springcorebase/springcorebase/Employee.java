package com.springcorebase.springcorebase;

public interface Employee {

	
	void doWork();
}
